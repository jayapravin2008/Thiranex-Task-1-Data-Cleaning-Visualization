# Thiranex Internship – Task 1 Report

## Title
**Data Cleaning & Visualization Project**

## Objective
The objective is to clean a raw sales dataset and visualize important business insights.

## Dataset
The dataset contains order ID, date, city, category, units sold, unit price, discount and revenue.

## Data Cleaning
The raw data was inspected for missing values, duplicate records and extreme values. Duplicate rows were removed. Missing categorical values were replaced with the mode and missing numerical values with the median. Numerical outliers were handled using the Interquartile Range (IQR) method. Revenue was recalculated after cleaning.

## Results
- Raw records: 102
- Records after duplicate removal: 100
- Duplicate records removed: 2
- Missing cells before cleaning: 13
- Missing cells after cleaning: 0
- Highest-revenue city: Coimbatore
- Highest-revenue category: Grocery
- Total cleaned revenue: 1325227.77

## Visualizations
Four visualizations were created: revenue by city, revenue by category, revenue distribution and monthly revenue trend.

## Conclusion
The project demonstrates a complete beginner-friendly data preprocessing and visualization workflow using Python. The cleaned data is more suitable for reliable analysis and reporting.
