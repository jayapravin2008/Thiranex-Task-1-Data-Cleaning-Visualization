# Thiranex Internship – Task 1: Data Cleaning & Visualization

## Objective
Clean and analyze a raw sales dataset and create visual reports of important findings.

## Tools
- Python
- Pandas
- NumPy
- Matplotlib
- Jupyter Notebook

## Data-cleaning steps
1. Loaded the raw CSV.
2. Checked data types, missing values and duplicate rows.
3. Converted date and numeric columns to correct types.
4. Removed duplicate records.
5. Filled categorical missing values using the mode.
6. Filled numerical missing values using the median.
7. Detected extreme numerical values using the IQR method and capped them.
8. Recalculated Revenue for consistency.
9. Saved the cleaned dataset.

## Visualizations
- Total revenue by city
- Total revenue by category
- Revenue distribution
- Monthly revenue trend

## Files
- `sales_data_raw.csv` – raw dataset
- `sales_data_cleaned.csv` – cleaned dataset
- `Task_1_Data_Cleaning_Visualization.ipynb` – complete notebook
- PNG files – generated visualizations
- `summary.json` – project summary

## How to run
Install:
```bash
pip install pandas numpy matplotlib jupyter
```
Then open the notebook:
```bash
jupyter notebook Task_1_Data_Cleaning_Visualization.ipynb
```
